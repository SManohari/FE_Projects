import project from '../asset/projects/project.png'

const projectData = [ 
  { 
    id : 1, 
    projectImage : project, 
    projectName : "YouTube Clone" , 
    demoLink:"" , 
    sourceLink :""
  }, 
  { 
    id : 2, 
    projectImage : project, 
    projectName : "To Do List" ,
    demoLink:"" , 
    sourceLink :""
  }, 
  {  id : 3,
     projectImage : project, 
     projectName : "Amazon Clone" ,
     demoLink:"" , 
     sourceLink :""
    },
  { id : 4, 
    projectImage : project, 
    projectName : "Rock Paper Scissor" ,
    demoLink:"" , 
    sourceLink :""
  }, 
  {  id : 5,
     projectImage : project, 
     projectName : "To Do List - React" ,
     demoLink:"" , 
     sourceLink :""
    },
  { id : 6, 
    projectImage : project,
    projectName : "Keeper App" ,
    demoLink:"" ,
    sourceLink :""
    }
   ] 
   export default projectData;