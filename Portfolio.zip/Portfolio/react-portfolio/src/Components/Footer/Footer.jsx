import './Footer.css';

function Footer(){
  return(
     <footer className ="para">
       <p>© 2025 Manohari. All rights reserved.</p>
     </footer>
  )   
}

export default Footer;
