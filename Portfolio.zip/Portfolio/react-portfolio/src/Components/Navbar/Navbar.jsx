
import './Navbar.css'
import AnchorLink from 'react-anchor-link-smooth-scroll';
import menuIcon from '../../../asset/nav/menuIcon.png'

function Navbar(){
  return (
    <nav className = "navContainer">
      <div>
        <p className ="title" >Mano</p>
      </div>
       
      <div className = "menu">
        {/* <img src ={menuIcon} className ="menuIcon"/> */}
        <ul className ="menuItems">
          <li>
            <AnchorLink className ="Anchor-Link" offset={200} href="#about"><p>About</p></AnchorLink>  
          </li>
          <li>
             <AnchorLink className ="Anchor-Link" offset={100} href="#skill"><p>Skills</p></AnchorLink>
          </li>
          <li>
             <AnchorLink className ="Anchor-Link" offset={100} href="#projects"><p>Projects</p></AnchorLink>
          </li>
          <li>
             <AnchorLink className ="Anchor-Link" offset={50} href="#contact"><p>Contact</p></AnchorLink>
          </li>
        </ul>
      </div>
    </nav>
  )
}

export default Navbar;